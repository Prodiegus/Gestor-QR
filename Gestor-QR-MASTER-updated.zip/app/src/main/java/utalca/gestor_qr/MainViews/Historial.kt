
package utalca.gestor_qr.MainViews

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import androidx.fragment.app.Fragment
import utalca.gestor_qr.MainModel.Serializador
import utalca.gestor_qr.QRAdapter
import utalca.gestor_qr.R

class Historial : Fragment() {
    private lateinit var qrListView: ListView
    private lateinit var qrAdapter: QRAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_historial, container, false)
        qrListView = view.findViewById(R.id.qr_list_view)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        cargarHistorial()
    }

    private fun cargarHistorial() {
        val serializador = Serializador(requireContext())
        val qrList = serializador.cargarTodosQR()
        qrAdapter = QRAdapter(requireContext(), qrList)
        qrListView.adapter = qrAdapter
    }
}
