
package utalca.gestor_qr

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class QRAdapter(context: Context, private val qrList: List<QR>) : ArrayAdapter<QR>(context, 0, qrList) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val qr = getItem(position)
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_qr, parent, false)
        
        val qrTextView = view.findViewById<TextView>(R.id.qr_text)
        qrTextView.text = qr?.content

        return view
    }
}
