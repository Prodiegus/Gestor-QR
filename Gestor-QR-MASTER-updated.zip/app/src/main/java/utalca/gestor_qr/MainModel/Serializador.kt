
package utalca.gestor_qr.MainModel

import android.content.Context
import android.util.Log
import android.widget.Toast
import java.io.*

class Serializador(private val context: Context) {

    fun guardarQR(qr: QR, filename: String) {
        val file = File(context.filesDir, filename)
        ObjectOutputStream(FileOutputStream(file)).use { it.writeObject(qr) }
        Log.d("Serializador", "QR guardado en \${file.absolutePath}")
        Toast.makeText(context, "QR guardado en \${file.absolutePath}", Toast.LENGTH_SHORT).show()
    }

    fun cargarQR(filename: String): QR? {
        val file = File(context.filesDir, filename)
        if (!file.exists()) return null
        return ObjectInputStream(FileInputStream(file)).use { it.readObject() as? QR }
    }

    fun cargarTodosQR(): List<QR> {
        val qrList = mutableListOf<QR>()
        val files = context.filesDir.listFiles()
        files?.forEach { file ->
            val qr = cargarQR(file.name)
            qr?.let { qrList.add(it) }
        }
        return qrList
    }
}
